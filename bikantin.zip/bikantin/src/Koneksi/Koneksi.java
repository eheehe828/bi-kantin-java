package Koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {
    public static Connection configDB() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/db_bikantin";
        String user = "root";
        String pass = "";   
        return DriverManager.getConnection(url, user, pass);
    }
}